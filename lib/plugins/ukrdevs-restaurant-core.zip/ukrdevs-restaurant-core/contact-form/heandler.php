<?php
require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );
	
   // Only process POST reqeusts.
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the form fields and remove whitespace.
        $name = strip_tags(trim($_POST["input_name"]));
        $phone = strip_tags(trim($_POST["input_phone"]));
        $email = filter_var(trim($_POST["input_email"]), FILTER_SANITIZE_EMAIL);
        $message = trim($_POST["textarea_message"]);

        // Check that data was sent to the mailer.
        if ( empty($name) OR empty($message) OR !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Set a 400 (bad request) response code and exit.
            http_response_code(400);
            esc_html_e("Oops! There was a problem with your submission. Please complete the form and try again.", 'restocore');
            exit;
        }

        // Set the recipient email address.
        $recipient = get_option('admin_email');

        // Set the email subject.
        $subject = esc_html__('Contact Form: Message from', 'restocore') . ' ' . $name;
 
        // Build the email content.
        $email_content  = esc_html__('Name:',	'restocore') . " $name\n";        
        $email_content .= esc_html__('Email:',	'restocore') . " $email\n";
        $email_content .= esc_html__('Phone:',	'restocore') . " $phone\n\n";        
        $email_content .= esc_html__('Message:','restocore') . "\n$message\n";

        // Build the email headers.
        $email_headers = "From: $name <$email>";

        // Send the email.
        if (wp_mail($recipient, $subject, $email_content, $email_headers)) {
            // Set a 200 (okay) response code.
            http_response_code(200);
            esc_html_e('Thank You! Your message has been sent.', 'restocore');
        } else {
            // Set a 500 (internal server error) response code.
            http_response_code(500);
            esc_html_e('Oops! Something went wrong and we couldn\'t send your message.', 'restocore');
        }

    } else {
        // Not a POST request, set a 403 (forbidden) response code.
        http_response_code(403);
        esc_html_e( 'There was a problem with your submission, please try again.', 'restocore' );
    }

?>
