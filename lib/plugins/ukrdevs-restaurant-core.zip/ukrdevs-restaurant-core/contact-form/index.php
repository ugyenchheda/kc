<?php


if ( !function_exists( 'add_action' ) ) {
	echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
	exit;
}
function restocore_cf_scripts() {
	wp_enqueue_script( 'restocore-cf-ajax', plugin_dir_url(__FILE__) . 'ajax.js', array('jquery') );	
}
add_action( 'wp_enqueue_scripts', 'restocore_cf_scripts' );


add_shortcode( 'contact_form', 'restocore_contact_form' );

function restocore_contact_form($args){ 
	ob_start();
	?>
	
	<section>
		<div class="center">
				<div class="section-title">
					<?php if( $args ): ?>
						<?php if( isset($args['subtitle']) ): ?>
							<p><?php esc_html_e($args['subtitle']); ?></p>
						<?php endif; ?>
						
						<?php if( isset($args['title']) ): ?>				
							<h3 class="pr-font">
								<?php esc_html_e($args['title']); ?>
							</h3>
						<?php endif; ?>
					<?php else: ?> 			
							<p><?php esc_html_e('Send Us Message', 'restocore'); ?></p>							
							<h3 class="pr-font"><?php esc_html_e('Contact Form', 'restocore'); ?></h3>
					<?php endif; ?>
				</div>
			<form id="ajax-contact" action="<?php echo plugin_dir_url(__FILE__);?>/heandler.php" method="post">
				<div id="form-messages"></div>
				<div class="cols-3 margin-large">
					<div class="form-item">
						<label for="input-name"><?php esc_html_e( 'Your Name', 'restocore' ); ?> *</label>
						<input type="text" id="input-name" name="input_name" class="required">
					</div>
					<div class="form-item">
						<label for="input-email"><?php esc_html_e( 'Your Email', 'restocore' ); ?> *</label>
						<input type="email" id="input-email" name="input_email" class="required">
					</div>
					<div class="form-item">
						<label for="input-phone"><?php esc_html_e( 'Your Phone', 'restocore' ); ?></label>
						<input type="tel" id="input-phone" name="input_phone">
					</div>							
				</div>
				<div class="form-item">
					<label for="textarea-message"><?php esc_html_e( 'Message', 'restocore' ); ?> *</label>
					<textarea id="textarea-message" name="textarea_message" class="required"></textarea>
				</div>
				<button type="submit" class="btn-form"><?php esc_html_e( 'Submit', 'restocore' ); ?></button>
			</form>
		</div>
	</section>
	
	<?php 
	return ob_get_clean();
}