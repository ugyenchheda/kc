<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings           = array(
  'menu_title'      => esc_html__('Theme Options', 'restocore'),
  'menu_type'       => 'menu', // menu, submenu, options, theme, etc.
  'menu_slug'       => 'cs-framework',
  'ajax_save'       => false,
  'show_reset_all'  => false,
  'framework_title' => esc_html__('Theme Options', 'restocore'),
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options        = array();



$options[] = array(
		'name'		=> 'general_section',
		'title'		=>	esc_html__( 'Page Layout', 'restocore' ),
		'icon'		=>	'fa fa-columns',
		'fields'	=> array(
			array(
				'id'		=>	'ukrdevs_site_layout',
				'type'		=>	'radio',
				'title'		=>	esc_html__( 'Select boxed or wide layout.', 'restocore' ),
				'options'	=>	array(
					'wide' 	=>	esc_html__( 'Wide layout', 'restocore' ),
					'boxed'	=>	esc_html__( 'Boxed layout', 'restocore' ),
				),
				'default'	=>	'wide',
			),
			array(
				'id'		=>	'ukrdevs_bg_pattern',
				'type'		=>	'image_select',
				'title'		=>	esc_html__( 'Select a Background Pattern', 'restocore' ),
				'options'	=> array(
					'pattern-bg1'    => get_template_directory_uri() . '/images/patterns/admin/bg1.png',
					'pattern-bg2'    => get_template_directory_uri() . '/images/patterns/admin/bg2.png',
					'pattern-bg3'    => get_template_directory_uri() . '/images/patterns/admin/bg3.png',
					'pattern-bg4'    => get_template_directory_uri() . '/images/patterns/admin/bg4.png',
					'pattern-bg5'    => get_template_directory_uri() . '/images/patterns/admin/bg5.png',
					'pattern-bg6'    => get_template_directory_uri() . '/images/patterns/admin/bg6.png',
					'pattern-bg7'    => get_template_directory_uri() . '/images/patterns/admin/bg7.png',
					'pattern-bg8'    => get_template_directory_uri() . '/images/patterns/admin/bg8.png',
					'pattern-bg9'    => get_template_directory_uri() . '/images/patterns/admin/bg9.png',
					'pattern-bg10'   => get_template_directory_uri() . '/images/patterns/admin/bg10.png',
					'pattern-bg11'   => get_template_directory_uri() . '/images/patterns/admin/bg11.png',
				),
				'default'	=>	'pattern-bg1',
				'info'		=> esc_html__('Background pattern shows only on boxed layout!', 'restocore'),
			),			
			array(
				'id'		=>	'ukrdevs_header',
				'type'		=>	'image_select',
				'title'		=>	esc_html__( 'Select a Header Layout', 'restocore' ),
				'options'	=> array(
					'v1'    => get_template_directory_uri() . '/images/headers/v1.png',
					'v2'    => get_template_directory_uri() . '/images/headers/v2.png',
					'v3'    => get_template_directory_uri() . '/images/headers/v3.png',
					'v4'    => get_template_directory_uri() . '/images/headers/v4.png',
				),
				'radio'        => true,
				'default'      => 'v2',
			),
			array(
				'id'		=>	'ukrdevs_welcome_msg',
				'type'		=>	'text',
				'title'		=>	esc_html__( 'Welcome Message', 'restocore' ),
				'info'   	=>  esc_html__( 'Show on top bar (Header #4)', 'restocore' ),
				'default' 	=>  'Welcome to Cristiano Restaurant Theme!',
			),
		),
	
);
// ------------------------------
// PRESENTATION SLIDER          -
// ------------------------------
$options[]   = array(
	'name'     => 'slider_section',
	'title'    => esc_html__('Presentation Slider', 'restocore'),
	'icon'     => 'fa fa-picture-o',
	'fields' => array(
        array(
			'id'		=> 'site_title',
			'type'		=> 'text',
			'title'		=> esc_html__('Title', 'restocore'),
			'default'	=> 'Cristiano Restaurant',
        ),
        array(
			'id'    	=> 'site_subtitle',
			'type'  	=> 'text',
			'title' 	=> esc_html__('Sub Title', 'restocore'),
			'default'	=> '123 Main Street, Uni 21, New York City',
        ),
        array(
			'id'		=> 'slider_images',
			'type'		=> 'gallery',
			'title'		=> esc_html__('Slider Images', 'restocore'),
			'info'		=> esc_html__('Use max 3 images with 1920x1080 size for better perfomance.', 'restocore')
		),
		array(
			'id'		=> 'slider_active',
			'type'		=> 'switcher',
			'title'		=> esc_html__('Slider on Home Page', 'restocore'),
			'default'	=> true,
		),
    ),
);
// ------------------------------
// CONTACT DETAILS              -
// ------------------------------
$curency_symbol = cs_get_option('dishes_menu_currency');
if(!$curency_symbol){
	$curency_symbol = '$';
}
$options[]   = array(
	'name'	=> 'menu_section',
	'title'	=> esc_html__('Dishes Menu', 'restocore'),
	'icon'	=> 'fa fa-cutlery',
	'fields' => array(
		array(
			'id'		=> 'dishes_menu_currency',
			'type'		=> 'text',
			'title'		=> esc_html__('Currency Symbol', 'restocore'),
			'default'	=> '$',
		),
		array(
			'id'		=> 'dishes_menu_currency_position',
			'type'		=> 'select',
			'title'		=> esc_html__('Currency Position', 'restocore'),			
			'options'	=> array(
				'left' 			=> esc_html__('Left', 'restocore') . ' (' . $curency_symbol . '99.99)',
				'right' 		=> esc_html__('Right', 'restocore') . ' (99.99' . $curency_symbol . ')',
				'left_space'	=> esc_html__('Left with Space', 'restocore') . ' (' . $curency_symbol . ' 99.99)',
				'right_space'	=> esc_html__('Right with Space', 'restocore') .  ' (99.99 ' . $curency_symbol . ')',
			),
			'default'	=> 'left',
			'info'		=> esc_html__('Please select the position of the currency symbol.','realty-core'),			
		),
	),
);
// ------------------------------
// CONTACT DETAILS              -
// ------------------------------
$options[]   = array(
  'name'     => 'contact',
  'title'    => esc_html__('Contact Details', 'restocore'),
  'icon'     => 'fa fa-location-arrow',
  'fields' => array(
		array(
          'id'        => 'fieldset_address',
          'type'      => 'fieldset',
          'title'     => esc_html__('Address', 'restocore'),
          'fields'    => array(
            array(
              'id'    => 'address_location',
              'type'  => 'text',
              'title' => esc_html__('Actual Address', 'restocore'),
            ),
            array(
              'id'    => 'address_notes',
              'type'  => 'text',
              'title' => esc_html__('Address Notes', 'restocore'),
            ),
            array(
              'id'    => 'google_map_location',
              'type'  => 'text',
              'title' => esc_html__( 'Google Map Location', 'restocore' ),
            ),
             array(
              'id'    => 'google_map_zoom',
              'type'  => 'text',
              'title' => esc_html__( 'Map Zoom Level', 'restocore' ),
              'info'  => esc_html__( 'Diapason from 3 to 20', 'restocore' ),
            ),            
             array(
              'id'    => 'google_map_api',
              'type'  => 'text',
              'title' => esc_html__( 'Google Map API', 'restocore' ),
              'info'  => 'https://developers.google.com/maps/documentation/javascript/get-api-key'
            ),    
            array(
              'id'    => 'open_table_id',
              'type'  => 'text',
              'title' => esc_html__( 'Open Table Restaurant ID', 'restocore' ),
            ),    
          ),
          'default' => array(
	          'address_location' => '123 Main Street, Uni 21, New York City',
	          'address_notes' => 'Lorem Ipsum Dolor',
	          'google_map_location' => '40.715028, -74.017775',
	          'google_map_zoom' => '12',
	          'google_map_api'	=>'',	          
	          'open_table_id' => '',
          ),                  
        ),
        
		array(
          'id'        => 'fieldset_phones',
          'type'      => 'fieldset',
          'title'     => esc_html__( 'Phone Number (s)', 'restocore' ),
          'fields'    => array(
            array(
              'id'    => 'phone_1',
              'type'  => 'text',
              'title' => esc_html__('Phone', 'restocore') . ' 1',
            ),
            array(
              'id'    => 'phone_2',
              'type'  => 'text',
              'title' => esc_html__('Phone', 'restocore') . ' 2',
            ),
            array(
              'id'    => 'phone_3',
              'type'  => 'text',
              'title' => esc_html__('Phone', 'restocore') . ' 3',
            ),   
            array(
              'id'    => 'phone_4',
              'type'  => 'text',
              'title' => esc_html__('Phone', 'restocore') . ' 4',
            ),                              
          ),
          'default'   => array(
	          'phone_1' => '+38 (012) 34 56 789',
			  ),
        ),
        
		array(
          'id'        => 'fieldset_hours',
          'type'      => 'fieldset',
          'title'     => esc_html__( 'Working Hours', 'restocore' ),
          'fields'    => array(
            array(
              'id'    => 'hours_1',
              'type'  => 'text',
              'title' => esc_html__('Row', 'restocore') . ' 1',
            ),
            array(
              'id'    => 'hours_2',
              'type'  => 'text',
              'title' => esc_html__('Row', 'restocore') . ' 2',
            ),
            array(
              'id'    => 'hours_3',
              'type'  => 'text',
              'title' => esc_html__('Row', 'restocore') . ' 3',
            ),                                     
          ),
          'default'   => array(
	          'hours_1' => 'Mon - Fri: 08:00 am - 10:00 pm',
	          'hours_2' => 'Sat - Sun: 10:00 am - 11:00 pm',
			),
        ),       
    ),
);



$options[]   = array(
  'name'     => 'social',
  'title'    => esc_html__('Social Networks', 'restocore'),
  'icon'     => 'fa fa-globe',
  'fields' => array(
	  
		array(
          'id'        => 'fieldset_social',
          'type'      => 'fieldset',
          'title'     => esc_html__( 'Social Networks', 'restocore' ),
          'fields'    => array(
            array(
              'id'    => 'facebook',
              'type'  => 'text',
              'title' => 'Facobook',
	          'attributes'    => array(
	            'placeholder' => esc_html__( 'Social Url', 'restocore' ),
	          ),            
            ),
            array(
              'id'    => 'twitter',
              'type'  => 'text',
              'title' => 'Twitter',
	          'attributes'    => array(
	            'placeholder' => esc_html__( 'Social Url', 'restocore' ),
	          ),               
            ),
            array(
              'id'    => 'google-plus',
              'type'  => 'text',
              'title' => 'Google Plus',
	          'attributes'    => array(
	            'placeholder' => esc_html__( 'Social Url', 'restocore' ),
	          ),               
            ),
            array(
              'id'    => 'youtube-play',
              'type'  => 'text',
              'title' => 'YouTube',
	          'attributes'    => array(
	            'placeholder' => esc_html__( 'Social Url', 'restocore' ),
	          ),               
            ),                     
            array(
              'id'    => 'vk',
              'type'  => 'text',
              'title' => 'Vkontakte',
	          'attributes'    => array(
	            'placeholder' => esc_html__( 'Social Url', 'restocore' ),
	          ),               
            ),
             array(
              'id'    => 'instagram',
              'type'  => 'text',
              'title' => 'Instagram',
	          'attributes'    => array(
	            'placeholder' => esc_html__( 'Social Url', 'restocore' ),
	          ),               
            ),  
             array(
              'id'    => 'pinterest',
              'type'  => 'text',
              'title' => 'Pinterest',
	          'attributes'    => array(
	            'placeholder' => esc_html__( 'Social Url', 'restocore' ),
	          ),               
            ),   
             array(
              'id'    => 'tripadvisor',
              'type'  => 'text',
              'title' => 'TripAdvisor',
	          'attributes'    => array(
	            'placeholder' => esc_html__( 'Social Url', 'restocore' ),
	          ),               
            ),
			 array(
              'id'    => 'yelp',
              'type'  => 'text',
              'title' => 'Yelp',
	          'attributes'    => array(
	            'placeholder' => esc_html__( 'Social Url', 'restocore' ),
	          ),               
            ),                                                                   
          ),
        ),
	),	  
);


CSFramework::instance( $settings, $options );
