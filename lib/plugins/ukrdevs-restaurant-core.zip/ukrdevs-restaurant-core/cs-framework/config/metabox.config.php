<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options      = array();

$options[] = array(
	'id'	=> 'dishes_menu_data',
	'title' 	=> esc_html__('Product Options', 'restocore'),
	'post_type'	=> 'dishes_menu',
	'context'   => 'side',
	'priority'  => 'high',
	'sections'	=> array(
		array(
			'name'  => 'dm_product_options',
			'fields' => array(
				array(
					'id'	=> 'price',
					'type'	=> 'text',
					'title'	=> esc_html__('Price', 'restocore'),
					'info'	=> esc_html__('No currency symbols', 'restocore'),
					'attributes' => array(
						'style'	=> 'width: 100px;'
					),
				),
				array(
					'id'	=> 'highlight',
					'type'	=> 'text',
					'title'	=> esc_html__('Highlight', 'restocore'),
				),
			),
		),
	),
);
// -----------------------------------------
// Page Metabox Google Maps Options        -
// -----------------------------------------
$options[]    = array(
  'id'        => '_custom_page_options',
  'title'     => esc_html__( 'Page Options', 'restocore' ),
  'post_type' => 'page',
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(
	 array(
	      'name'  => 'section_1',
	      'title' => esc_html__( 'Page Layout', 'restocore' ),
	      'icon'  => 'fa fa-columns',
	      'fields' => array(
		    array(
				'id'		=>	'ukrdevs_page_layout',
				'type'		=>	'radio',
				'title'		=>	esc_html__( 'Select boxed or wide layout.', 'restocore' ),
				'options'	=>	array(
					'default'	=> esc_html__( 'Default', 'restocore' ),
					'wide' 		=> esc_html__( 'Wide layout', 'restocore' ),
					'boxed'		=> esc_html__( 'Boxed layout', 'restocore' ),
				),
				'default'	=>	'default',
			),
		),// end: fields
	),// end: a section
    // begin: a section
    array(
      'name'  => 'section_2',
      'title' => esc_html__( 'Our Menu', 'restocore' ),
      'icon'  => 'fa fa-cutlery',      
      // begin: fields
      'fields' => array(
	  		array(
				'id'         => 'dishes_cat',
				'type'       => 'checkbox',
				'title'      => esc_html__( 'Chose categories to display', 'restocore' ),
				'info' => esc_html__('Choose what menu category you want to display on this page. Leave blank for all categories.', 'restocore'),				
				'options'    => 'categories',
				'query_args' => array(
					'taxonomy'	=> 'dishes_categories',
				),
			),
			array(
				'id'		=> 'dishes_cols',
				'type'		=> 'radio',
				'title'		=> esc_html__('Display', 'restocore'),
				'options'	=> array(
					'col-1'	=> esc_html__('1 Column', 'restocore'),
					'cols-2'=> esc_html__('2 Columns', 'restocore'),					
				),
				'default'	=> 'cols-2',
			),				
		), // end: fields
    ), // end: a section
	 array(
	      'name'  => 'section_3',
	      'title' => esc_html__( 'Google Map', 'restocore' ),
	      'icon'  => 'fa fa-map-marker',
	      'fields' => array(
		     array(
	          'id'    => 'google_map_switcher',
	          'type'  => 'switcher',
	          'title' => esc_html__('Google Map Before Footer', 'restocore'),
		    ),
		),// end: fields
	),// end: a section
  ),
);

CSFramework_Metabox::instance( $options );
