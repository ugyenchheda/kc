<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// SHORTCODE GENERATOR OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options       = array();


// -----------------------------------------
// Template  Shortcode      
// -----------------------------------------

if(class_exists('woocommerce')) {
	$options[] = array(
		'title'      => esc_html__( 'WooCommerce Shortcodes', 'restocore' ),
		'shortcodes' => array(
			array(
				'name'      => 'product_cat',
				'title'     => esc_html__('Product Categories', 'restocore'),
				'fields'    => array(
			        array(
						'id'    => 'title',
						'type'  => 'text',
						'title'	=> esc_html__( 'Title', 'restocore' ),
			        ),
			        array(
						'id'    => 'subtitle',
						'type'  => 'text',
						'title'	=> esc_html__( 'Sub Title', 'restocore' ),
			        ),
			        array(
				        'id'	=> 'carousel',
				        'type'	=> 'switcher',
				        'title'	=> esc_html__( 'Carousel', 'restocore' ),
				        'default' => true,
			        ),    			
				),
			),
			array(
				'name'      => 'star_products',
				'title'     => esc_html__('Featured Star Products', 'restocore'),
				'fields'    => array(
			        array(
						'id'    => 'title',
						'type'  => 'text',
						'title'	=> esc_html__( 'Title', 'restocore' ),
			        ),
			        array(
						'id'    => 'subtitle',
						'type'  => 'text',
						'title'	=> esc_html__( 'Sub Title', 'restocore' ),
			        ),		        			
				),
			),			
		),
	);
}
$options[]     = array(
	'title'      => esc_html__( 'Template Shortcodes', 'restocore' ),
	'shortcodes' => array(
		array(
			'name'		=> 'promo_slider',
			'title'		=> 'Promo Slider',
			'fields'    => array(
				array(
					'type'    => 'content',
					'content' => esc_html__('Just click to "Insert Shortcode, this is adding a single shortcode', 'restocore'),
				),
			),			
		),
		array(
			'name'		=> 'our_menu_teaser',
			'title'		=> esc_html__( 'Our Menu Teaser (Random menu items)', 'restocore' ),
			'fields'	=> array(
				array(
					'id'	=> 'title',
					'type'	=> 'text',
					'title'	=> esc_html__( 'Title', 'restocore' ),
				),
				array(
					'id'	=> 'subtitle',
					'type'	=> 'text',
					'title'	=> esc_html__( 'Sub Title', 'restocore' )
				),
				array(
					'id'         => 'cat',
					'type'       => 'checkbox',
					'title'      => esc_html__( 'Chose categories to display', 'restocore' ),
					'options'     => 'categories',
					'query_args'    => array(
						'taxonomy'	=> 'dishes_categories',
					),
				),				
				array(
					'id'	=> 'uri',
					'type'	=> 'text',
					'title'	=> esc_html__( 'Full Menu URI', 'restocore' ),
				),
			),
		),
		array(
			'name'		=> 'our_menu',
			'title'		=> esc_html__( 'Our Menu (Full Menu)', 'restocore' ),
			'fields'	=> array(
				array(
					'id'         => 'cat',
					'type'       => 'checkbox',
					'title'      => esc_html__( 'Chose categories to display', 'restocore' ),
					'options'     => 'categories',
					'query_args'    => array(
						'taxonomy'	=> 'dishes_categories',
					),
				),
			),
		),
		array(
			'name'		=> 'short_info',
			'title'		=> esc_html__( 'Short Info', 'restocore' ),
			'fields'	=> array(
				array(
					'id'	=> 'text',
					'type'	=> 'text',
					'title'	=> esc_html__( 'Short Info', 'restocore' ),
				),
			),
		),
		array(
			'name'		=> 'contact_details',
			'title'		=> esc_html__( 'Contact Details', 'restocore' ),
			'fields'    => array(
		        array(
					'id'    => 'title',
					'type'  => 'text',
					'title'	=> esc_html__( 'Title', 'restocore' ),
		        ),
		        array(
					'id'    => 'subtitle',
					'type'  => 'text',
					'title'	=> esc_html__( 'Sub Title', 'restocore' ),
		        ),		        			
			),			
		),
		array(
			'name'		=> 'contact_form',
			'title'		=> esc_html__( 'Contact Form', 'restocore' ),
			'fields'    => array(
		        array(
					'id'    => 'title',
					'type'  => 'text',
					'title'	=> esc_html__( 'Title', 'restocore' ),
		        ),
		        array(
					'id'    => 'subtitle',
					'type'  => 'text',
					'title'	=> esc_html__( 'Sub Title', 'restocore' ),
		        ),		        			
			),			
		),		
		array(
			'name'		=> 'open_table_reservation',
			'title'		=> esc_html__( 'Open Table Reservation', 'restocore' ),
			'fields'    => array(
		        array(
					'id'    => 'title',
					'type'  => 'text',
					'title'	=> esc_html__( 'Title', 'restocore' ),
		        ),
		        array(
					'id'    => 'subtitle',
					'type'  => 'text',
					'title'	=> esc_html__( 'Sub Title', 'restocore' ),
		        ),		        			
			),			
		),
	),
);
CSFramework_Shortcode_Manager::instance( $options );
