<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// TAXONOMY OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options     = array();

// -----------------------------------------
// Taxonomy Options                        -
// -----------------------------------------

$options[]   = array(
  'id'       => '_restocore_wc_product_cat',
  'taxonomy' => 'product_cat', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    array(
      'id'    => 'restocore_wc_cat_header_img',
      'type'  => 'image',
      'add_title' => esc_html__('Add Header Image','restocore'),

    ),

  ),
);

CSFramework_Taxonomy::instance( $options );