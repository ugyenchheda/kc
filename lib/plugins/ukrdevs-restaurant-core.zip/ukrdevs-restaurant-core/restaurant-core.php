<?php
/*
Plugin Name: Restaurant Core
Description: Plugin developed for Restaurnat Business. Based on Codestar Framework. Included Our Menu, Promo Slider Contact Form and some aditional shortcodes for WooCommerce.
Version:     1.5
Author:      UkrDevs
Author URI:  http://ukrdevs.com
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: restocore
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'RESTAURANTCORE_PLUGIN_URL', __FILE__ );

register_activation_hook( RESTAURANTCORE_PLUGIN_URL, 'restaurantcore_activate' );

include_once('restaurant-functions.php');
include_once('cs-framework/cs-framework.php');
include_once('type-our-menu/init.php');
include_once('type-promo-slider/init.php');
include_once('contact-form/index.php');
//include_once('ocdi/one-click-demo-import.php');
//add_filter( 'pt-ocdi/import_files', 'ocdi_import_files' );

add_filter( 'body_class','restocore_bg_pattern' );	// Body Class for Background Patterns

/** Shortcodes */
include_once( 'shortcodes/contact-details.php' );			// Include Shortcode file - Contact Details
include_once( 'shortcodes/open-table-reservation.php' );	// Include Shortcode file - Open Table Reservation
include_once( 'shortcodes/short-info.php' );				// Include Shortcode file - Short Info

add_shortcode( 'open_table_reservation', 'restaurantcore_open_table_reservation' );	// Open Table Reservation Shortcode
add_shortcode( 'contact_details', 'restocore_contact_details' );				// Contact Details Shortcode
add_shortcode( 'short_info', 'restocore_short_info' );							    // Short Info Shortcpde	

/** WooCommerce Shortcodes */
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if(is_plugin_active('woocommerce/woocommerce.php')) {
	include_once( 'shortcodes/product-categories.php' ); 	// Include Shortcode WooCommerce - Promo Slider	
	include_once( 'shortcodes/star-products.php' );  		// Include Shortcode WooCommerce - Featured Products
	add_shortcode( 'product_cat', 'restaurantcore_product_categories' );
	add_shortcode( 'star_products', 'restaurantcore_star_products' );
}