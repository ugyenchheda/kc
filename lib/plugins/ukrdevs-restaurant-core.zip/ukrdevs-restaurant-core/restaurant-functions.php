<?php
function restaurantcore_activate() {	
	if ( version_compare( get_bloginfo('version'), '4.5', '<' ) ) {
		wp_die( esc_html__( 'You must have a minimum version of 4.5 to use this plugin', 'restocore') );
	}
	$args = array(
		'codestar-framework/cs-framework.php',
		'cristiano-shortcodes/index.php',
		'cristiano-dishes-menu/index.php',	
		'cristiano-promo-slider/index.php',	
		'cristiano-contact-form/index.php',
	);	
	deactivate_plugins($args);
	delete_plugins($args);
}
function ocdi_import_files() {
	return array(
		array(
			'import_file_name'	=> 'Demo Import 1',
			'local_import_file'	=> plugin_dir_url(RESTAURANTCORE_PLUGIN_URL) . '/ocdi/demo-data/cristiano.wordpress.xml',
			'import_notice'		=> __( 'After you import this demo, you will have to setup the slider separately.', 'restocore' ),
		),
	);
}
function restocore(){
	return true;
}

/* GET META DATA / $arg = METABOX ID
---------------------------------------------------------------- */
function restocore_get_meta_data( $arg ){
	$meta_data = get_post_meta( get_queried_object_id(), '_custom_page_options', true );
	if( !empty($meta_data[$arg]) ) {
		return $meta_data[$arg];
	}
}

/* GET TERM DATA / $arg = TERM DATA ID
---------------------------------------------------------------- */
function restocore_get_wc_product_header_img() {
	$term_data = get_term_meta( get_queried_object_id(), '_restocore_wc_product_cat', true );
	if( !empty($term_data) ) {
		$img_id = $term_data['restocore_wc_cat_header_img'];
		$img = wp_get_attachment_image_src($img_id );	
		return $img[0];			
	}
}

/* SLIDER
---------------------------------------------------------------- */
function restocore_slider() {
	$slider_active = cs_get_option( 'slider_active' );
	if($slider_active == true) {
		get_template_part('template-parts/presentation-slider');	
	}
}



	



/* SHOW GOOGLE MAP
---------------------------------------------------------------- */
function restocore_google_map() {
	$google_map = get_post_meta( get_queried_object_id(), '_custom_page_options', true );
	if($google_map) {
		if( !empty($google_map['google_map_switcher']) ){
			get_template_part( 'template-parts/part', 'google_map' );
		}
	}
}

/* BACKGROUND PATTERN
---------------------------------------------------------------- */
function restocore_bg_pattern( $classes ){
	$site_layout = cs_get_option( 'ukrdevs_site_layout' );	
	$page_layout = restocore_get_meta_data('ukrdevs_page_layout');
	if( $site_layout == 'boxed' && $page_layout !== 'wide' || $page_layout == 'boxed') {
		$bg_pattern = cs_get_option( 'ukrdevs_bg_pattern' );
		$classes[] = $bg_pattern;		
	}
	$slider_active = cs_get_option( 'slider_active' );	
	if(is_front_page() && $slider_active == true) {
		$classes[] = 'header-opacity';		
	}
	return $classes;
}

/* WELCOME MESSAGE
---------------------------------------------------------------- */
function restocore_welcome_msg(){
	$welcome_msg = cs_get_option( 'ukrdevs_welcome_msg' );
	if( $welcome_msg ) {
		echo esc_html( $welcome_msg );
	}
}

/* SHOW SOCIAL LINKS
---------------------------------------------------------------- */
function restocore_social(){
	$socials = cs_get_option( 'fieldset_social' );
	if( is_array( $socials ) ) {
		foreach( $socials as $class => $url  ) {
			if($url): ?>
				<a class="fa fa-<?php echo esc_attr($class) ?>" href="<?php echo esc_url( $url ) ?>" target="blank"></a>
			<?php endif;
		}
	}
}

/* SHOW ADDRESS
---------------------------------------------------------------- */
function restocore_address( $tag = NULL ){
	$address_fieldset = cs_get_option( 'fieldset_address' );
	$address = $address_fieldset['address_location'];
	if( isset($address) ) {
		if( isset($tag) ) {
			echo "<$tag>" .  esc_html( $address )  . "</$tag>";
		} else {
			echo esc_html( $address );			
		}
	}
}

/* SHOW MOBILE NUMBER
---------------------------------------------------------------- */
function restocore_mobile_number( $tag = NULL ){
	$phone_number_fieldset = cs_get_option( 'fieldset_phones' );
	$phone_number = $phone_number_fieldset['phone_1'];
	if( isset($phone_number) ) {
		if( isset($tag) ) {
			echo "<$tag>" . esc_html($phone_number) . "</$tag>";
		} else {
			echo esc_html($phone_number);			
		}
	}
}

/* SHOW MOBILE NUMBERS in tag <li>
---------------------------------------------------------------- */
function restocore_mobile_numbers(){
	$phones = cs_get_option( 'fieldset_phones' );
	if( is_array( $phones ) ) {
		foreach( $phones as $phone ) {
			if($phone) {
				echo '<li>' . esc_html( $phone ) . '</li>';
			}
		}
	}
}

/* SHOW WORKING HOURS
---------------------------------------------------------------- */
function restocore_working_hours(){
	$hours = cs_get_option( 'fieldset_hours' );
	if( is_array( $hours ) ) {
		foreach( $hours as $hour ) {
			if( $hour ) {	
				echo '<li class="hours">' . esc_html( $hour ) . '</li>';		
			}
		}
	}
}