<?php
function restocore_contact_details( $args ){
	ob_start();	
	?>	
	<section id="contact-details" class="reset">
		<div class="center">
			<div class="section-title">
				<?php if( $args ): ?>
					<?php if( isset($args['subtitle']) ): ?>
						<p><?php esc_html_e( $args['subtitle'] ); ?></p>
					<?php endif; ?>
					<?php if( isset($args['title']) ): ?>				
						<h3 class="pr-font">
							<?php esc_html_e( $args['title'] ); ?>
						</h3>
					<?php endif; ?>
				<?php else: ?>
					<p><?php esc_html_e( 'Visit Us', 'restocore' ); ?></p>							
					<h3 class="pr-font"><?php esc_html_e('Our Location', 'restocore'); ?></h3>
				<?php endif; ?>
			</div>		
			<div class="cols-3 margin-large">
				<div>
					<div class="box phones">
						<h3 class="pr-font">
							<?php esc_html_e( 'Phones', 'restocore' ); ?>
						</h3>
						<ul>
							<?php restocore_mobile_numbers(); ?>
						</ul>
						<span class="fa fa-phone"></span>
					</div>
				</div>
				<div>
					<div class="box address">
						<h3 class="pr-font">
							<?php esc_html_e( 'Address', 'restocore' );  ?>
						</h3>				
						<ul>
							<li>
								<?php restocore_address(); ?>
								<br />
								<?php echo cs_get_option( 'fieldset_address' )[ 'address_notes' ]; ?>
							</li>
						</ul>
						<span class="fa fa-map-marker"></span>
					</div>
				</div>
				<div>
					<div class="box email">
						<h3 class="pr-font">
							<?php esc_html_e( 'Working Hours', 'restocore' ); ?>
						</h3>
						<?php $hours = cs_get_option( 'fieldset_hours' ); ?>
						<?php if( is_array( $hours ) ): ?>				
							<ul>
								<?php foreach( $hours as $hour ): ?>
									<li><?php echo esc_html( $hour ); ?></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
						<span class="fa fa-clock-o"></span>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php 
	return ob_get_clean();		
}