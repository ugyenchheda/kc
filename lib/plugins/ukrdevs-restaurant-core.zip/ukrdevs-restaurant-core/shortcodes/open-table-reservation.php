<?php
function restaurantcore_open_table_reservation( $args ) { 
		ob_start(); //64861 ?>
		

	<?php $restaurantID = cs_get_option( 'fieldset_address' )[ 'open_table_id' ]; ?>
	
	<section id="open-table-reservation">
		<div class="section-title">
			<?php if( $args ): ?>
				<?php if( isset($args['subtitle']) ): ?>
					<p><?php esc_html_e( $args['subtitle'] ); ?></p>
				<?php endif; ?>
				<?php if( isset($args['title']) ): ?>				
					<h3 class="pr-font">
						<?php esc_html_e( $args['title'] ); ?>
					</h3>
				<?php endif; ?>
			<?php else: ?>			
				<p><?php esc_html_e('Open Table', 'restocore'); ?></p>
				<h3 class="pr-font"><?php esc_html_e('Book a Table', 'restocore') ?></h3>
			<?php endif; ?>
		</div>
		<div class="center">
			<form method="get" class="otw-widget-form" action="//www.opentable.com/restaurant-search.aspx" target="_blank">
			
				<div class="cols-3 margin-large">
					<div class="form-item">
						<label for="date"><?php esc_html_e('Date', 'restocore'); ?></label>
						<input id="date" name="startDate" class="otw-reservation-date" type="text" value="" autocomplete="off">
					</div>
					<div class="form-item">
						<label for="time"><?php esc_html_e('Time', 'restocore'); ?></label>
						<select id="time" name="ResTime" class="otw-reservation-time otw-selectpicker">
							<?php
							//Time Loop
							//@SEE: http://stackoverflow.com/questions/6530836/php-time-loop-time-one-and-half-of-hour
							$inc = 30 * 60;
							$start = ( strtotime( '8AM' ) ); // 6  AM
							$end = ( strtotime( '11:59PM' ) ); // 10 PM
							for ( $i = $start; $i <= $end; $i += $inc ) {
								// to the standart format
								$time      = date( 'g:i a', $i );
								$timeValue = date( 'g:ia', $i );
								$default   = "7:00pm";
								echo "<option value=\"$timeValue\" " . ( ( $timeValue == $default ) ? ' selected="selected" ' : "" ) . ">$time</option>" . PHP_EOL;
							}
		
							?>
						</select>				
					</div>
					<div class="form-item">
						<label for="party"><?php esc_html_e('Party size', 'restocore'); ?></label>
						<select id="party" name="partySize" class="otw-party-size-select selectpicker">
							<option value="1">1 <?php esc_html_e('Person', 'restocore'); ?></option>
							<option value="2" selected="selected">2 <?php esc_html_e('People', 'restocore'); ?></option>
							<option value="3">3 <?php esc_html_e('People', 'restocore'); ?></option>
							<option value="4">4 <?php esc_html_e('People', 'restocore'); ?></option>
							<option value="5">5 <?php esc_html_e('People', 'restocore'); ?></option>
							<option value="6">6 <?php esc_html_e('People', 'restocore'); ?></option>
							<option value="7">7 <?php esc_html_e('People', 'restocore'); ?></option>
							<option value="8">8 <?php esc_html_e('People', 'restocore'); ?></option>
							<option value="9">9 <?php esc_html_e('People', 'restocore'); ?></option>
							<option value="10">10 <?php esc_html_e('People', 'restocore'); ?></option>
						</select>
					</div>
				</div>
				<div class="align-center">
					<input type="submit" class="find-table-btn" value="<?php esc_attr_e( 'Find a Table', 'restocore' ); ?>" />
				</div>
				<input type="hidden" name="RestaurantID" class="RestaurantID" value="<?php echo esc_attr( $restaurantID) ; ?>">
				<input type="hidden" name="rid" class="rid" value="<?php echo $restaurantID; ?>">
				<input type="hidden" name="GeoID" class="GeoID" value="15">
				<input type="hidden" name="txtDateFormat" class="txtDateFormat" value="MM/dd/yyyy">
				<input type="hidden" name="RestaurantReferralID" class="RestaurantReferralID" value="<?php echo esc_attr($restaurantID); ?>">
			</form>
		</div>
	</section>
	
	<?php 
	return ob_get_clean();
}