<?php
function restaurantcore_product_categories( $args ) {
	ob_start();
	$carousel = '';
	?>	
		<section id="order-online">
			<div class="center">
				<?php if( $args ): ?>
					<div class="section-title">
						<?php if( isset($args['subtitle']) ): ?>
							<p><?php esc_html_e($args['subtitle']); ?></p>
						<?php endif; ?>
						
						<?php if( isset($args['title']) ): ?>				
							<h3 class="pr-font">
								<?php esc_html_e($args['title']); ?>
							</h3>
						<?php endif; ?>
						<?php if( isset($args['carousel']) ): ?>
							<?php $carousel = $args['carousel']; ?>
						<?php endif; ?>
					</div>
				<?php endif; ?> 
				<?php
					$args = array(
						'hide_empty' => false,
					);
					$product_categories = get_terms( 'product_cat', $args );
					$cols =  count( $product_categories );
					
					if($cols < 4) {
						$swiper = '';
						$cols_wrap = "cols-$cols";
					}
					elseif($carousel == '1'){
						$swiper = 'swiper';
						$cols_wrap = 'swiper-wrapper';						
					}	
					else {
						$swiper = '';
						$cols_wrap = "cols-4 margin-large";						
					}
				?>
				<?php if ( $product_categories ) : ?>
				
				<div id="categories-wrapper" class="<?php echo esc_attr( $swiper ); ?>"> 
					<ul id="categories-list" class="<?php echo esc_attr( $cols_wrap ); ?>">
						<?php
						foreach ( $product_categories as $category ) {
								wc_get_template( 'content-product_cat.php', array(
									'category' => $category
								) );
							}
						?>
					</ul>
					<div class="swiper-pagination bullet-<?php echo esc_attr( $cols ); ?>"></div>
				</div>
	
				<?php endif; ?>
			</div>
		</section>
	<?php
	return ob_get_clean();
}