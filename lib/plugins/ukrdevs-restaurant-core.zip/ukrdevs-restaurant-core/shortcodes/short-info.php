<?php

function restocore_short_info( $args ){
	ob_start();
	?>	
		<section class="short-info">
			<div class="center">
				<?php if(isset( $args['text'] )): ?>
					<h2 class="pr-font"><?php echo esc_html( $args['text'] ) ?></h2>
				<?php endif; ?>
			</div>
		</section>
	<?php
	return ob_get_clean();		
}