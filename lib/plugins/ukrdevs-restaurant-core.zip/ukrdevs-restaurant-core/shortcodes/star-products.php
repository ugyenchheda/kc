<?php
function restaurantcore_star_products( $args ) {
	ob_start();
	$query_args = array(
		'posts_per_page'	=> 3,
		'no_found_rows'		=> 1,
		'post_status'		=> 'publish',
		'post_type'			=> 'product',
		'meta_key'			=> '_featured',
		'meta_value'		=> 'yes',
		'orderby'           => 'rand',
	);
	$featured_products = new WP_Query( $query_args );
	?>
	
	<?php if ( $featured_products->have_posts() ): ?>
		<section id="most-popular">
			<div class="center">
				<?php if($args): ?>
					<div class="section-title">
						<?php if(isset( $args['subtitle'] )): ?>
							<p><?php echo esc_html( $args['subtitle'] ) ?></p>
						<?php endif; ?>	
						<?php if(isset( $args['title'] )): ?>	
							<h3 class="pr-font"><?php echo esc_html( $args['title'] ); ?></h3>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<ul id="product-list" class="cols-3 margin-large">
					<?php while ( $featured_products->have_posts() ): ?>
						<?php
							$featured_products->the_post();				
							get_template_part('woocommerce/content', 'product');
						?>
					<?php endwhile; ?>
				</ul>
			</div>
		</section>			
	<?php endif; ?>
	<?php
	return ob_get_clean();		
}