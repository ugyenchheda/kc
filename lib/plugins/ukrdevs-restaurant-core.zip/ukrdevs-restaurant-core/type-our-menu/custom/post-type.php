<?php
function our_menu_posttype(){
	$labels = array(
		'name'               => esc_html__( 'Our Menu', 'restocore' ),
		'singular_name'      => esc_html__( 'Dish', 'restocore' ),
		'menu_name'          => esc_html__( 'Our Menu', 'restocore' ) . ' ▹',
		'name_admin_bar'     => esc_html__( 'Dish', 'restocore' ),
		'add_new'            => esc_html__( 'Add New Dish', 'restocore' ),
		'add_new_item'       => esc_html__( 'Add New Dish', 'restocore' ),
		'new_item'           => esc_html__( 'New Dish', 'restocore' ),
		'edit_item'          => esc_html__( 'Edit Dish', 'restocore' ),
		'view_item'          => esc_html__( 'View Dish', 'restocore' ),
		'all_items'          => esc_html__( 'All Dishes', 'restocore' ),
		'search_items'       => esc_html__( 'Search Dishes', 'restocore' ),
		'parent_item_colon'  => esc_html__( 'Parent Dishes:', 'restocore' ),
		'not_found'          => esc_html__( 'No dishes found.', 'restocore' ),
		'not_found_in_trash' => esc_html__( 'No dishes found in Trash.', 'restocore' ),
	);
	$args = array(
		'labels'             => $labels,
		'menu_icon'			 => 'dashicons-editor-ul',
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => true,
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 4,
		'supports'           => array( 'title', 'editor', 'thumbnail' ),
	);
	register_post_type( 'dishes_menu', $args );
}