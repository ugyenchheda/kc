<?php
function our_menu_taxonomy() {
	$args = array(
		'label'				=> esc_html__('Categories', 'restocore'),
		'hierarchical'      => true,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => true,
	);
	register_taxonomy( 'dishes_categories', 'dishes_menu', $args );
}