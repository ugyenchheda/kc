<?php

function restocore_dishes_price(){
	global $post;
	$post_meta = get_post_meta( $post->ID, 'dishes_menu_data', true );
	
	$currency_symbol = cs_get_option('dishes_menu_currency');
	$currency_option = cs_get_option('dishes_menu_currency_position');
	if(isset($post_meta['price'])) {
		switch ( $currency_option ) {
			case 'left':
				echo '<span class="currency">' . $currency_symbol . '</span>' . $post_meta['price'];
				break;
			case 'right':
				echo $post_meta['price'] . '<span class="currency">' . $currency_symbol . '</span>';
				break;
			case 'left_space':
				echo '<span class="currency">' . $currency_symbol . '</span> ' . $post_meta['price'];
				break;
			case 'right_space':
				echo $post_meta['price'] . ' <span class="currency">' . $currency_symbol . '</span>';
				break;
			default: echo $post_meta['price'];
		}
	}
}

function restocore_highlight_text() {
	global $post;
	$post_meta = get_post_meta( $post->ID, 'dishes_menu_data', true );
	if(!empty($post_meta['highlight'])) {
		echo '<span class="highlight-text">' . $post_meta['highlight'] . '</span>';
	}
}