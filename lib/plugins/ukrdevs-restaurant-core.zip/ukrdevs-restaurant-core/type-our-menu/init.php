<?php

include_once('custom/post-type.php');
include_once('custom/taxonomy.php');

include_once( 'shortcodes/our-menu-teaser.php' );
include_once( 'shortcodes/our-menu.php' );
include_once( 'functions.php' );

add_action( 'init', 'our_menu_posttype' ); //Custom Post Type Init
add_action( 'init', 'our_menu_taxonomy' ); //Custom Taxonomy Init

add_shortcode( 'our_menu', 'restaurantcore_our_menu' );
add_shortcode( 'our_menu_teaser', 'restaurantcore_our_menu_teaser' );


