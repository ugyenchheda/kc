<?php
	function restaurantcore_our_menu_teaser( $args ) {
		ob_start();
		
		$cat_array = '';				
		if( isset( $args['cat'] )) {			
			$cat_array = explode(",", $args['cat']);
		}
		
		$query_args = array(
			'post_type' => 'dishes_menu',
			'posts_per_page' => 6,
			'orderby'        => 'rand',
			'tax_query' => array(
				array(
					'taxonomy' => 'dishes_categories',
					'field'    => 'id',
					'terms'    => $cat_array,
				),
			),
		);
		$the_query = new WP_Query( $query_args );
	?>
	<section id="our-menu">
		<div class="center">
			<?php if( $args ): ?>
				<div class="section-title">
					<?php if(isset( $args['subtitle'] )): ?>
						<p><?php echo esc_html( $args['subtitle'] ); ?></p>		
					<?php endif; ?>	
					<?php if(isset( $args['title'] )): ?>
						<h3 class="pr-font"><?php echo esc_html( $args['title'] ); ?></h3>
					<?php endif;?>			
				</div>
			<?php endif; ?>
			<?php if ( $the_query->have_posts() ) : ?>
				<ul class="dishes-menu cols-2 margin-large">
					<?php while ( $the_query->have_posts() ): $the_query->the_post() ?>
						<?php get_template_part( 'template-parts/loop', 'our-menu' ); ?>
					<?php endwhile; ?>
				</ul>
			<?php endif; ?>
			<?php if( isset( $args['uri']) ): ?>
				<div class="align-center">
					<a href="<?php echo $args['uri']; ?>" class="btn-color"><?php esc_html_e( 'View Full Menu', 'restocore' ) ?></a>
				</div>
			<?php endif; ?>
		</div>
	</section>				
	<?php 
	return ob_get_clean();		
}