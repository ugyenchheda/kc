<?php
function restaurantcore_our_menu($args) {
	ob_start();
		$cat_array = '';
		if(isset($args['cat'])) {
			$cat_array = $args['cat'];
		}
		$term_args = array(
			'hide_empty' => true,
			'include'	=> $cat_array,
	    );
		$tax_terms = get_terms( 'dishes_categories', $term_args );
	?>
	<?php if( !empty($tax_terms) ): ?>
		<div id="dishes-menu" class="reset">
			<?php foreach ($tax_terms as $tax_term): ?>
				<div class="section-title">
					<h3 class="pr-font">
						<?php echo $tax_term->name; ?>
					</h3>
				</div>	
				<?php 
					$args = array(
						'post_type' => 'dishes_menu',
						'dishes_categories' => $tax_term->slug,
						'nopaging' => true,
					);
					$the_query = new WP_Query( $args );
				?>
				
				<?php if ( $the_query->have_posts() ) : ?>
					<ul class="dishes-menu cols-2 margin-large">
						<?php while ( $the_query->have_posts() ): $the_query->the_post() ?>
							<?php get_template_part( 'template-parts/loop', 'our-menu' ); ?>
						<?php endwhile; ?>
					</ul>
				<?php else: ?>
					<p class="woocommerce-info">
						<?php echo esc_html_e('No products were found matching your selection.', 'restocore'); ?>
					</p>
				<?php endif; ?>
				
			<?php endforeach; ?>
		</div>
	<?php else: ?>
		<div class="center">
			<?php 
				$args = array(
					'post_type' => 'dishes_menu',
					'nopaging' => true,
	
				);
				$the_query = new WP_Query( $args );
			?>
			<?php if ( $the_query->have_posts() ) : ?>
				<ul class="dishes-menu cols-2 margin-large">
					<?php while ( $the_query->have_posts() ): $the_query->the_post() ?>				
						<?php get_template_part( 'template-parts/loop', 'our-menu' ); ?>
					<?php endwhile; ?>
				</ul>
			<?php else: ?>
				<p class="woocommerce-info">
					<?php echo esc_html_e('No products were found matching your selection.', 'restocore'); ?>
				</p>
			<?php endif; ?>
		</div>		
	<?php endif;
	return ob_get_clean();
}