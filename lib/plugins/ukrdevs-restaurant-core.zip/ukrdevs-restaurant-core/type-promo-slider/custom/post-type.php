<?php
function promo_slider_posttype(){
	$labels = array(
		'name'               => esc_html__( 'Promo Slider', 'restocore' ),
		'singular_name'      => esc_html__( 'Slide', 'restocore' ),
		'menu_name'          => esc_html__( 'Promo Slider', 'restocore' ) . ' ▹',
		'name_admin_bar'     => esc_html__( 'Slide', 'restocore' ),
		'add_new'            => esc_html__( 'Add New Slide', 'restocore' ),
		'add_new_item'       => esc_html__( 'Add New Slide', 'restocore' ),
		'new_item'           => esc_html__( 'New Slide', 'restocore' ),
		'edit_item'          => esc_html__( 'Edit Slide', 'restocore' ),
		'view_item'          => esc_html__( 'View Slide', 'restocore' ),
		'all_items'          => esc_html__( 'All Slides', 'restocore' ),
		'search_items'       => esc_html__( 'Search Slides', 'restocore' ),
		'parent_item_colon'  => esc_html__( 'Parent Slides:', 'restocore' ),
		'not_found'          => esc_html__( 'No slides found.', 'restocore' ),
		'not_found_in_trash' => esc_html__( 'No slides found in Trash.', 'restocore' ),
	);
	$args = array(
		'labels'             => $labels,
		'menu_icon'			 => 'dashicons-images-alt2',		
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => true,
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => true,
		'menu_position'      => 4,
		'supports'           => array( 'title', 'editor', 'thumbnail' ),
	);
	register_post_type( 'promo_slider', $args );
}