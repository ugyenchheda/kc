<?php

function restaurantcore_promo_slider(){
	ob_start();
	$args = array( 'post_type' => 'promo_slider');
	$loop = new WP_Query( $args );
	?>
	<?php if($loop->have_posts()): ?>
		<section id="promo-slider">
			<div class="swiper-wrapper">
				<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
					<?php get_template_part('template-parts/loop', 'promo-slider'); ?>
				<?php endwhile; ?>
			</div>
			<div class="swiper-pagination"></div>	
		</section>
	<?php endif; ?>
	<?php
	return ob_get_clean();
}